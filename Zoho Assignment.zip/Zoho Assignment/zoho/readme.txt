config.php - configure database
login.php - allows user to login
register.php - allows user to register
forgotpass.php - helps user recover their password.
comment.php - allows user to leave a comment and saves it.
logout.php - allows user to logout

Steps to Run:

- Install XAMPP on the PC.
- Copy the "zoho" folder from the zip and go to C:\xampp\htdocs & paste the zoho folder here.
- Open XAMPP Control Panel.
- Run Apache & MySQL.
- Go to the browser & type "localhost/zoho".
- Open the "login.php" file from there.
- Sign Up through the Sign up button in navbar.
- Login through Sign In button.
- Enter your comments.
- Sign out.